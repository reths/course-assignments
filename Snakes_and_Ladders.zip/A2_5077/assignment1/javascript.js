function showPass(x){
    var p;
    if(x===1){
         p = document.getElementById("passwrd1");
    }else if(x===2){
         p = document.getElementById("passwrd2");
    }
    if(p.type === "password") {
        p.type = "text";
    } else{
        p.type = "password";
    }
}

function checkPass(){
    var password1=document.getElementById("passwrd1").value;
    var password2=document.getElementById("passwrd2").value;
    var message=document.getElementById("wrongpasswordmessage");

    //empty message because if the passwords are same, we dont want the message to stay.
    if(password1 !== password2){
        message.textContent = "The passwords are not the same!";
    }else{
        message.textContent=""
    }
}

function passStrengthCkeck(){
    var buttonApply= document.getElementById("submitbutt");
    var password=document.getElementById("passwrd1").value;
    var message=document.getElementById("strengthmessage");
    var lowerpassword= password.toLowerCase();
    var numberCount=0;
    var i=0;
    var charAmmount={};

    if(lowerpassword === "fire" ||lowerpassword === "fotia" || lowerpassword === "ethelontis" ||lowerpassword === "volunteer"){
        message.textContent="Weak password. Has banned words!";
        return false;
    }



    for(i=0;i<password.length;i++){
        if(/\d/.test(password[i])){
            numberCount++;
        }
    }
    if(((password.length)/2)<numberCount){
        message.textContent="Weak password. More than half are numbers!";
        return false;
    }


    for(i=0;i<password.length;i++){
        char = password[i];
        if(charAmmount[char] === undefined){
            charAmmount[char]=1;

        }else{
            charAmmount[char]++;
        }
        if(((password.length)/2)<charAmmount[char] ){
            message.textContent="Weak password. Many character repeats!";
            return false;
        }
    }

    if( (/[`~!@#$%^&*()_\-+={}\[\]|\\:;"',./<>?]/.test(password)) &&
        (/[A-Z]/.test(password)) &&
        (/\d/.test(password)) &&
        (/[a-z]/.test(password)))
    {
        message.textContent= "Strong Password!";
        buttonApply.disabled = false;
        return true;
    }else{
        message.textContent="Medium Password!";
        return false;
    }
}

function isVolunteer(x){
    const div=document.getElementById("volunteerChoices");
    if(x===true){
        div.style.display = "block";
    }else{
        div.style.display = "none";
    }
}

function changeRules(type){
    const divnormal=document.getElementById("rulesNormalDiv");
    const divvolunteer=document.getElementById("rulesVolunteerDiv");
    if(type === true){
        divvolunteer.style.display="block";
        divnormal.style.display="none";
        document.getElementById("rules").checked=true;
    }else if(type === false){
        divvolunteer.style.display="none";
        divnormal.style.display="block";
        document.getElementById("rules_volunteer").checked=true;
    }
}

function ageValidity(){
    var buttonApply= document.getElementById("submitbutt");
    var usersBirthdate= new Date(document.getElementById("birthdate").value);
    var todayDate=new Date();

    buttonApply.disabled = (todayDate.getFullYear() - usersBirthdate.getFullYear()) < 18 || (todayDate.getFullYear() - usersBirthdate.getFullYear()) > 55;

}

function catchSubmit(event){
    event.preventDefault();
    const Data = new FormData(document.getElementById("fireForm"));
    const answersObj = Object.fromEntries(Data.entries());
    document.getElementById("jason").innerText = JSON.stringify(answersObj, null, 2);
}